import { useState } from "react";
import { Lock, CheckCircle, Play } from "lucide-react";
import Orbs from "@/components/quiz/Orbs";
import AudioPlayer from "@/components/quiz/AudioPlayer";
import UpsellBanner from "@/components/quiz/UpsellBanner";

const DAYS = Array.from({ length: 21 }, (_, i) => ({
  day: i + 1,
  title: [
    "Reconhecendo o Padrão",
    "Mapeando Gatilhos Emocionais",
    "Diário de Consciência",
    "Quebrando o Primeiro Ciclo",
    "Reprogramação de Crenças",
    "Meditação de Desapego",
    "Criando Novos Limites",
    "Comunicação Assertiva",
    "Reconexão com Intuição",
    "Identificando Red Flags",
    "Fortalecendo o Self",
    "Exercício de Espelho",
    "Ritual de Soltar",
    "Visualização de Futuro",
    "Prática de Autocompaixão",
    "Recalibrando Expectativas",
    "Construindo Segurança Interna",
    "Atraindo com Intenção",
    "Protocolo de Clareza",
    "Celebrando Evolução",
    "Integração Final",
  ][i],
  unlocked: i < 3,
  completed: false,
  audioSrc: "", // placeholder
}));

const Dashboard = () => {
  const [days] = useState(DAYS);

  return (
    <div className="min-h-screen px-5 py-8 bg-gradient-deep relative">
      <Orbs />

      <div className="max-w-md mx-auto relative z-10">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-2 h-2 rounded-full bg-primary animate-breathe" />
          <span className="text-primary text-xs font-medium uppercase tracking-[0.2em]">
            Plano de Desbloqueio
          </span>
        </div>

        <h1 className="text-3xl font-light text-foreground mb-2 tracking-tight">
          Seus 21 Dias de{" "}
          <span className="text-gradient-spirit font-medium italic">Transformação</span>
        </h1>
        <p className="text-muted-foreground text-sm mb-8 font-light">
          Complete um exercício por dia para reprogramar seu padrão.
        </p>

        <div className="space-y-3 mb-8">
          {days.map((day) => (
            <div
              key={day.day}
              className={`bg-gradient-card-glass border-glass rounded-2xl p-4 transition-all ${
                !day.unlocked ? "opacity-50" : ""
              }`}
            >
              <div className="flex items-center gap-3 mb-2">
                <div
                  className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                    day.completed
                      ? "bg-accent/20 border border-accent/30"
                      : day.unlocked
                      ? "bg-primary/20 border border-primary/30"
                      : "bg-secondary border border-border"
                  }`}
                >
                  {day.completed ? (
                    <CheckCircle className="w-4 h-4 text-accent" />
                  ) : day.unlocked ? (
                    <Play className="w-3 h-3 text-primary ml-0.5" />
                  ) : (
                    <Lock className="w-3 h-3 text-muted-foreground" />
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-foreground text-sm font-medium">
                    Dia {day.day}
                  </p>
                  <p className="text-muted-foreground text-xs truncate">
                    {day.title}
                  </p>
                </div>
              </div>

              {day.unlocked && day.audioSrc && (
                <div className="mt-2">
                  <AudioPlayer src={day.audioSrc} title={day.title} />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Upsell */}
        <UpsellBanner />

        <p className="text-muted-foreground text-xs text-center mt-8 mb-4">
          Novos dias são desbloqueados a cada 24 horas.
        </p>
      </div>
    </div>
  );
};

export default Dashboard;
