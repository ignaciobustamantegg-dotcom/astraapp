import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Orbs from "@/components/quiz/Orbs";
import OrderBump from "@/components/quiz/OrderBump";
import { Sparkles } from "lucide-react";

const SuccessScreen = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setRevealed(true), 800);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center px-5 py-12 bg-gradient-deep relative">
      <Orbs />

      <div className="max-w-md w-full relative z-10 animate-fade-in-up">
        {/* Reveal animation */}
        <div className={`text-center transition-all duration-1000 ${revealed ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}>
          <div className="w-16 h-16 rounded-full bg-primary/20 border border-primary/40 flex items-center justify-center mx-auto mb-6 animate-breathe">
            <Sparkles className="w-7 h-7 text-primary" />
          </div>

          <h1 className="text-3xl sm:text-4xl font-light text-foreground mb-3 leading-tight tracking-tight">
            Seu Arquétipo:{" "}
            <span className="text-gradient-spirit font-medium italic block mt-1">
              A Guardiã Ferida
            </span>
          </h1>

          <div className="w-12 h-[1px] bg-primary/30 my-8 mx-auto" />

          <div className="bg-gradient-card-glass border-glass rounded-2xl p-5 mb-6 text-left space-y-4">
            <p className="text-secondary-foreground text-sm leading-relaxed font-light">
              Você protege quem ama com tanta intensidade que acaba se anulando no processo. Seu padrão de repetição vem de uma <span className="text-foreground font-medium">ferida de abandono primária</span> que te leva a aceitar menos do que merece para não ficar sozinha.
            </p>
            <p className="text-secondary-foreground text-sm leading-relaxed font-light">
              A causa raiz está ligada a um <span className="text-foreground font-medium">vínculo emocional não resolvido</span> que faz você atrair inconscientemente parceiros que reforçam a crença de que você precisa "merecer" o amor.
            </p>
          </div>

          <div className="bg-gradient-card-glass border-glass rounded-2xl p-5 mb-6 text-left">
            <p className="text-xs text-muted-foreground uppercase tracking-widest mb-3">
              🗝️ Chave de Descoberta
            </p>
            <p className="text-foreground text-sm leading-relaxed font-light">
              Seu desbloqueio começa quando você entende que <span className="text-gradient-spirit font-medium">seu valor não depende de quem fica</span>. O Plano de 21 Dias foi calibrado para reprogramar essa crença raiz e abrir espaço para conexões genuínas.
            </p>
          </div>
        </div>

        {/* Order Bump */}
        <div className="mb-6">
          <OrderBump />
        </div>

        {/* Go to Dashboard */}
        <button
          onClick={() => navigate("/dashboard")}
          className="flex items-center justify-center gap-2.5 w-full px-8 py-4 rounded-2xl font-medium text-base tracking-wide bg-primary text-primary-foreground glow-button hover:brightness-110 active:scale-[0.97] transition-all duration-300"
        >
          Acessar Meu Plano de 21 Dias
        </button>

        <p className="text-muted-foreground text-xs text-center mt-4 tracking-wide">
          ✦ Acesso imediato ao seu plano personalizado
        </p>
      </div>
    </div>
  );
};

export default SuccessScreen;
