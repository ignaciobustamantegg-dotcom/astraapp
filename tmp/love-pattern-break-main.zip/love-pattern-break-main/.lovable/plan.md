

# Plano: Sistema de Audio + Pagina de Vendas Premium + Checkout + Dashboard Pos-Venda

## Resumo Geral

Adicionar feedback sonoro ao quiz, transformar a tela de resultados numa pagina de vendas com blur/suspense e urgencia, criar fluxo de checkout com Stripe, e construir um Dashboard de 21 Dias pos-pagamento com player de audio e upsell.

---

## Parte 1 — Feedback Sonoro no Quiz

### O que sera feito
- Criar um hook `useQuizSounds` que gera sons programaticamente via Web Audio API (sem arquivos externos)
- **Click premium**: tom curto e seco (frequencia aguda, decay rapido) ao selecionar uma opcao
- **Swoosh**: ruido filtrado com sweep de frequencia nas transicoes de tela
- **Pulso de dados**: tom grave pulsante que cresce em volume/frequencia na tela de processamento (TransitionScreen)

### Arquivos
- Novo: `src/hooks/useQuizSounds.ts` — hook com funcoes `playClick()`, `playSwoosh()`, `playDataPulse(progress)`
- Editado: `src/components/quiz/QuestionScreen.tsx` — chamar `playClick()` no `handleAnswer`
- Editado: `src/components/quiz/TransitionScreen.tsx` — chamar `playDataPulse(progress)` no loop de progresso, `playSwoosh()` ao montar
- Editado: `src/pages/Index.tsx` — chamar `playSwoosh()` nas transicoes de tela

---

## Parte 2 — Pagina de Vendas (ResultsScreen Reformulada)

### Abismo Cognitivo (Blur Gate)
- O diagnostico comeca visivel (termometros, texto introdutorio)
- O paragrafo final ("Chave de Descoberta") fica com `filter: blur(8px)` + overlay com icone de cadeado
- Texto borrado sera tentador: "Seu Arquetipo de Bloqueio e o ___. A causa raiz esta ligada a..."
- Novo componente: `BlurredContent.tsx`

### Animacao de IA Antes x Depois
- Novo componente: `BeforeAfterImages.tsx`
- Cross-fade automatico entre duas ilustracoes SVG (estado "caos" vs "clareza")
- Usa CSS animation com `opacity` alternando a cada 3 segundos
- Ilustracoes feitas como SVG inline (silhueta estilizada) para manter o design atual

### Prova Social Dinamica
- Secao com 5-6 mini avatares circulares com iniciais + nome + badge "Padrao Desbloqueado"
- Animacao staggered de entrada (cada avatar aparece com delay)
- Novo componente: `SocialProofAvatars.tsx`

### Sticky Timer de Urgencia
- Novo componente: `UrgencyTimer.tsx`
- Countdown de 5 minutos persistido em `sessionStorage`
- `position: fixed; bottom: 0` — aparece via `IntersectionObserver` quando o CTA final fica proximo
- Inclui botao CTA duplicado e animacao pulsante abaixo de 1 minuto

### Botao de Checkout
- Integracao com Stripe (sera habilitado como proximo passo)
- Por enquanto, o botao navega para `/sucesso?email=xxx` para simular o fluxo

---

## Parte 3 — Rota `/sucesso` (Pos-Pagamento)

### Nova pagina: `SuccessScreen.tsx`
- Recebe email via query param
- Exibe o conteudo que estava borrado, agora totalmente desbloqueado
- Revelacao do "Arquetipo" com animacao dramatica (fade-in lento + glow)
- Transicao automatica para o Dashboard de 21 Dias

---

## Parte 4 — Dashboard de 21 Dias

### Nova pagina: `src/pages/Dashboard.tsx` (rota `/dashboard`)
- Layout com 21 cards (dias), cada um com:
  - Titulo do exercicio/acao do dia
  - Icone de status (bloqueado/desbloqueado/completo)
  - Player de audio minimalista (componente `AudioPlayer.tsx`) com play/pause e barra de progresso
  - Audio gerado via URL placeholder (pode ser integrado com ElevenLabs depois)
- Dias 1-3 desbloqueados por padrao, restante bloqueado com visual de cadeado

### Order Bump no Checkout
- Componente `OrderBump.tsx` exibido na pagina de sucesso antes do dashboard
- Card com checkbox: "Adicionar Protocolo Acelerado por +R$17" (simulado)

### Banner de Upsell
- Componente `UpsellBanner.tsx` logo abaixo do cronograma de dias no Dashboard
- "Protocolo Short-Circuit: Acelere seus resultados em 7 dias" com CTA

### Player de Audio Minimalista
- Novo componente: `src/components/quiz/AudioPlayer.tsx`
- Botao play/pause circular + barra de progresso + duracao
- Estilo glass card consistente com o design atual

---

## Parte 5 — Rotas e Navegacao

Novas rotas no `App.tsx`:
- `/sucesso` — tela pos-pagamento
- `/dashboard` — dashboard de 21 dias

---

## Detalhes Tecnicos

### Som via Web Audio API (sem dependencias externas):
```text
playClick(): OscillatorNode 2000Hz, duration 30ms, gain decay
playSwoosh(): white noise + BiquadFilter sweep 1000->100Hz, 300ms
playDataPulse(p): OscillatorNode 80-200Hz baseado no progresso, gain crescente
```

### Blur progressivo (CSS):
```text
.blur-gate { filter: blur(8px); user-select: none; pointer-events: none; }
Overlay: position absolute, backdrop-blur, icone Lock, CTA
```

### Timer (sessionStorage):
```text
Key: "urgency_timer_start"
Se nao existe, salva Date.now()
Calcula remaining = 300s - elapsed
Se <= 0, mostra "Oferta expirada" (mas mantem botao)
```

### Arquivos novos (total: 7):
1. `src/hooks/useQuizSounds.ts`
2. `src/components/quiz/BlurredContent.tsx`
3. `src/components/quiz/BeforeAfterImages.tsx`
4. `src/components/quiz/SocialProofAvatars.tsx`
5. `src/components/quiz/UrgencyTimer.tsx`
6. `src/components/quiz/AudioPlayer.tsx`
7. `src/pages/SuccessScreen.tsx`
8. `src/pages/Dashboard.tsx`
9. `src/components/quiz/OrderBump.tsx`
10. `src/components/quiz/UpsellBanner.tsx`

### Arquivos editados (total: 5):
1. `src/App.tsx` — novas rotas
2. `src/pages/Index.tsx` — sons nas transicoes
3. `src/components/quiz/QuestionScreen.tsx` — som de click
4. `src/components/quiz/TransitionScreen.tsx` — som de pulso
5. `src/components/quiz/ResultsScreen.tsx` — reformulacao completa com blur, avatars, timer, before/after
6. `src/index.css` — animacoes de cross-fade, pulse-urgent, blur-gate

### Preservado (sem alteracao):
- Fontes (Cormorant Garamond + DM Sans)
- Paleta de cores (purple/blue/dark)
- Layout glass card
- Componentes Orbs, SocialProofPopup, ThermometerGauge, BeforeAfter, MiniRelato

